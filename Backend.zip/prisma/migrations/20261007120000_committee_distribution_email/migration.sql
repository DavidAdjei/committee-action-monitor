-- AlterTable
ALTER TABLE `committees` ADD COLUMN `distribution_email` VARCHAR(190) NULL;
