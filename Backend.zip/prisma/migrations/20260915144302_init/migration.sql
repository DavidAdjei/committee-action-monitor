-- CreateTable
CREATE TABLE `users` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `entra_object_id` VARCHAR(191) NULL,
    `full_name` VARCHAR(160) NOT NULL,
    `email` VARCHAR(190) NOT NULL,
    `department` VARCHAR(160) NULL,
    `active` BOOLEAN NOT NULL DEFAULT true,
    `is_central_committee` BOOLEAN NOT NULL DEFAULT false,
    `is_admin` BOOLEAN NOT NULL DEFAULT false,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `users_entra_object_id_key`(`entra_object_id`),
    UNIQUE INDEX `users_email_key`(`email`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `committees` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(180) NOT NULL,
    `code` VARCHAR(40) NOT NULL,
    `mandate` TEXT NULL,
    `meeting_frequency` VARCHAR(60) NULL,
    `chairperson_id` INTEGER NOT NULL,
    `secretary_id` INTEGER NOT NULL,
    `central_rep_id` INTEGER NOT NULL,
    `active` BOOLEAN NOT NULL DEFAULT true,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `committees_name_key`(`name`),
    UNIQUE INDEX `committees_code_key`(`code`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `committee_memberships` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `committee_id` INTEGER NOT NULL,
    `user_id` INTEGER NOT NULL,
    `role` ENUM('CHAIRPERSON', 'SECRETARY', 'MEMBER') NOT NULL,
    `start_date` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `end_date` DATETIME(3) NULL,
    `active` BOOLEAN NOT NULL DEFAULT true,

    INDEX `committee_memberships_user_id_active_idx`(`user_id`, `active`),
    UNIQUE INDEX `committee_memberships_committee_id_user_id_key`(`committee_id`, `user_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `meetings` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `committee_id` INTEGER NOT NULL,
    `reference` VARCHAR(80) NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `starts_at` DATETIME(3) NOT NULL,
    `ends_at` DATETIME(3) NULL,
    `venue` VARCHAR(255) NULL,
    `agenda` TEXT NULL,
    `teams_requested` BOOLEAN NOT NULL DEFAULT false,
    `teams_event_id` VARCHAR(255) NULL,
    `teams_join_url` TEXT NULL,
    `created_by_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `meetings_committee_id_reference_key`(`committee_id`, `reference`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `meeting_minutes` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `meeting_id` INTEGER NOT NULL,
    `status` ENUM('DRAFT', 'ISSUED', 'APPROVED') NOT NULL DEFAULT 'DRAFT',
    `source_population` ENUM('LATEST_MEETING', 'PREVIOUS_MEETING', 'ALL_OPEN_ACTIONS') NOT NULL DEFAULT 'LATEST_MEETING',
    `discussion` TEXT NULL,
    `document_url` TEXT NULL,
    `created_by_id` INTEGER NOT NULL,
    `issued_at` DATETIME(3) NULL,
    `approved_at` DATETIME(3) NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `minute_action_snapshots` (
    `minutes_id` INTEGER NOT NULL,
    `action_point_id` INTEGER NOT NULL,
    `source_meeting_id` INTEGER NULL,
    `action_status` VARCHAR(40) NOT NULL,
    `progress_percent` INTEGER NOT NULL,
    `owner_remarks` TEXT NULL,
    `captured_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`minutes_id`, `action_point_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `action_points` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `reference_no` VARCHAR(40) NOT NULL,
    `meeting_id` INTEGER NOT NULL,
    `committee_id` INTEGER NOT NULL,
    `title` VARCHAR(300) NOT NULL,
    `description` TEXT NULL,
    `minutes_reference` VARCHAR(120) NULL,
    `owner_id` INTEGER NOT NULL,
    `date_raised` DATE NOT NULL,
    `deadline` DATE NOT NULL,
    `revised_deadline` DATE NULL,
    `priority` ENUM('LOW', 'MEDIUM', 'HIGH', 'CRITICAL') NOT NULL DEFAULT 'MEDIUM',
    `status` ENUM('OPEN', 'IN_PROGRESS', 'OVERDUE', 'PENDING_VERIFICATION', 'COMPLETED', 'CANCELLED') NOT NULL DEFAULT 'OPEN',
    `progress` INTEGER NOT NULL DEFAULT 0,
    `status_reason` TEXT NULL,
    `completed_at` DATETIME(3) NULL,
    `verified_by_id` INTEGER NULL,
    `verified_at` DATETIME(3) NULL,
    `completion_note` TEXT NULL,
    `created_by_id` INTEGER NOT NULL,
    `version` INTEGER NOT NULL DEFAULT 0,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL,

    UNIQUE INDEX `action_points_reference_no_key`(`reference_no`),
    INDEX `ix_actions_deadline_status`(`deadline`, `status`),
    INDEX `ix_actions_owner`(`owner_id`, `status`),
    INDEX `ix_actions_committee`(`committee_id`, `status`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `action_stakeholders` (
    `action_point_id` INTEGER NOT NULL,
    `user_id` INTEGER NOT NULL,
    `stakeholder_type` ENUM('CHAIRPERSON', 'SECRETARY', 'ACTION_OWNER', 'CENTRAL_COMMITTEE', 'OTHER') NOT NULL,

    PRIMARY KEY (`action_point_id`, `user_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `action_updates` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `action_point_id` INTEGER NOT NULL,
    `author_id` INTEGER NOT NULL,
    `status` ENUM('OPEN', 'IN_PROGRESS', 'OVERDUE', 'PENDING_VERIFICATION', 'COMPLETED', 'CANCELLED') NOT NULL,
    `progress` INTEGER NOT NULL,
    `note` TEXT NOT NULL,
    `revised_deadline` DATE NULL,
    `evidence_link` TEXT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `evidence_files` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `action_update_id` INTEGER NOT NULL,
    `storage_key` VARCHAR(500) NOT NULL,
    `filename` VARCHAR(260) NOT NULL,
    `media_type` VARCHAR(150) NOT NULL,
    `size_bytes` INTEGER NOT NULL,
    `sha256` VARCHAR(64) NULL,
    `scan_result` VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    `uploaded_by_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `notifications` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `action_point_id` INTEGER NULL,
    `recipient_id` INTEGER NOT NULL,
    `channel` ENUM('EMAIL', 'IN_APP', 'TEAMS') NOT NULL,
    `notification_type` ENUM('CREATED', 'DAILY_REMINDER', 'OVERDUE_ESCALATION', 'STATUS_CHANGE', 'EVIDENCE_SUBMITTED', 'EVIDENCE_VERIFIED', 'MINUTES_ISSUED') NOT NULL,
    `idempotency_key` VARCHAR(255) NOT NULL,
    `scheduled_for` DATETIME(3) NOT NULL,
    `sent_at` DATETIME(3) NULL,
    `delivery_status` ENUM('PENDING', 'SENT', 'FAILED') NOT NULL DEFAULT 'PENDING',
    `error_message` VARCHAR(500) NULL,
    `read_at` DATETIME(3) NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `notifications_idempotency_key_key`(`idempotency_key`),
    INDEX `ix_notification_queue`(`delivery_status`, `scheduled_for`),
    INDEX `notifications_recipient_id_read_at_idx`(`recipient_id`, `read_at`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `audit_events` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `occurred_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `actor_user_id` INTEGER NULL,
    `action` VARCHAR(120) NOT NULL,
    `resource_type` VARCHAR(60) NOT NULL,
    `resource_id` INTEGER NULL,
    `committee_id` INTEGER NULL,
    `action_point_id` INTEGER NULL,
    `before` JSON NULL,
    `after` JSON NULL,
    `result` VARCHAR(20) NOT NULL,
    `correlation_id` VARCHAR(80) NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `committees` ADD CONSTRAINT `committees_chairperson_id_fkey` FOREIGN KEY (`chairperson_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `committees` ADD CONSTRAINT `committees_secretary_id_fkey` FOREIGN KEY (`secretary_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `committees` ADD CONSTRAINT `committees_central_rep_id_fkey` FOREIGN KEY (`central_rep_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `committee_memberships` ADD CONSTRAINT `committee_memberships_committee_id_fkey` FOREIGN KEY (`committee_id`) REFERENCES `committees`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `committee_memberships` ADD CONSTRAINT `committee_memberships_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `meetings` ADD CONSTRAINT `meetings_committee_id_fkey` FOREIGN KEY (`committee_id`) REFERENCES `committees`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `meetings` ADD CONSTRAINT `meetings_created_by_id_fkey` FOREIGN KEY (`created_by_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `meeting_minutes` ADD CONSTRAINT `meeting_minutes_meeting_id_fkey` FOREIGN KEY (`meeting_id`) REFERENCES `meetings`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `meeting_minutes` ADD CONSTRAINT `meeting_minutes_created_by_id_fkey` FOREIGN KEY (`created_by_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `minute_action_snapshots` ADD CONSTRAINT `minute_action_snapshots_minutes_id_fkey` FOREIGN KEY (`minutes_id`) REFERENCES `meeting_minutes`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `minute_action_snapshots` ADD CONSTRAINT `minute_action_snapshots_action_point_id_fkey` FOREIGN KEY (`action_point_id`) REFERENCES `action_points`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `action_points` ADD CONSTRAINT `action_points_meeting_id_fkey` FOREIGN KEY (`meeting_id`) REFERENCES `meetings`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `action_points` ADD CONSTRAINT `action_points_committee_id_fkey` FOREIGN KEY (`committee_id`) REFERENCES `committees`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `action_points` ADD CONSTRAINT `action_points_owner_id_fkey` FOREIGN KEY (`owner_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `action_points` ADD CONSTRAINT `action_points_created_by_id_fkey` FOREIGN KEY (`created_by_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `action_points` ADD CONSTRAINT `action_points_verified_by_id_fkey` FOREIGN KEY (`verified_by_id`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `action_stakeholders` ADD CONSTRAINT `action_stakeholders_action_point_id_fkey` FOREIGN KEY (`action_point_id`) REFERENCES `action_points`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `action_stakeholders` ADD CONSTRAINT `action_stakeholders_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `action_updates` ADD CONSTRAINT `action_updates_action_point_id_fkey` FOREIGN KEY (`action_point_id`) REFERENCES `action_points`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `action_updates` ADD CONSTRAINT `action_updates_author_id_fkey` FOREIGN KEY (`author_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `evidence_files` ADD CONSTRAINT `evidence_files_action_update_id_fkey` FOREIGN KEY (`action_update_id`) REFERENCES `action_updates`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `evidence_files` ADD CONSTRAINT `evidence_files_uploaded_by_id_fkey` FOREIGN KEY (`uploaded_by_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `notifications` ADD CONSTRAINT `notifications_action_point_id_fkey` FOREIGN KEY (`action_point_id`) REFERENCES `action_points`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `notifications` ADD CONSTRAINT `notifications_recipient_id_fkey` FOREIGN KEY (`recipient_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `audit_events` ADD CONSTRAINT `audit_events_actor_user_id_fkey` FOREIGN KEY (`actor_user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `audit_events` ADD CONSTRAINT `audit_events_committee_id_fkey` FOREIGN KEY (`committee_id`) REFERENCES `committees`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `audit_events` ADD CONSTRAINT `audit_events_action_point_id_fkey` FOREIGN KEY (`action_point_id`) REFERENCES `action_points`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
