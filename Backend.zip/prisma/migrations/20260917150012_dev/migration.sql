-- DropForeignKey
ALTER TABLE `committees` DROP FOREIGN KEY `committees_central_rep_id_fkey`;

-- AlterTable
ALTER TABLE `committees` MODIFY `central_rep_id` INTEGER NULL;

-- AddForeignKey
ALTER TABLE `committees` ADD CONSTRAINT `committees_central_rep_id_fkey` FOREIGN KEY (`central_rep_id`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
