/*
  Warnings:

  - A unique constraint covering the columns `[meeting_id]` on the table `meeting_minutes` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE `notifications` MODIFY `notification_type` ENUM('CREATED', 'DAILY_REMINDER', 'OVERDUE_ESCALATION', 'STATUS_CHANGE', 'EVIDENCE_SUBMITTED', 'EVIDENCE_VERIFIED', 'MINUTES_ISSUED', 'MEETING_ACTIONS_REMINDER', 'MEETING_MINUTES_REMINDER') NOT NULL;
