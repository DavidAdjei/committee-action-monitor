CREATE TABLE `meeting_papers` (
  `id` INTEGER NOT NULL AUTO_INCREMENT,
  `meeting_id` INTEGER NOT NULL,
  `storage_key` VARCHAR(500) NOT NULL,
  `filename` VARCHAR(260) NOT NULL,
  `media_type` VARCHAR(150) NOT NULL,
  `size_bytes` INTEGER NOT NULL,
  `uploaded_by_id` INTEGER NOT NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  INDEX `meeting_papers_meeting_id_idx`(`meeting_id`),
  CONSTRAINT `meeting_papers_meeting_id_fkey` FOREIGN KEY (`meeting_id`) REFERENCES `meetings`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `meeting_papers_uploaded_by_id_fkey` FOREIGN KEY (`uploaded_by_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
