-- AlterTable
ALTER TABLE `meetings` ADD COLUMN `attendance_sheet_url` TEXT NULL,
    ADD COLUMN `attendance_token` VARCHAR(64) NULL;

-- CreateTable
CREATE TABLE `meeting_attendance` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `meeting_id` INTEGER NOT NULL,
    `user_id` INTEGER NOT NULL,
    `method` ENUM('QR', 'UPLOAD', 'MANUAL') NOT NULL DEFAULT 'QR',
    `marked_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `note` VARCHAR(255) NULL,

    UNIQUE INDEX `meeting_attendance_meeting_id_user_id_key`(`meeting_id`, `user_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `meeting_attendance` ADD CONSTRAINT `meeting_attendance_meeting_id_fkey` FOREIGN KEY (`meeting_id`) REFERENCES `meetings`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `meeting_attendance` ADD CONSTRAINT `meeting_attendance_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
