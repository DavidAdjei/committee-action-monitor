-- Action comments (Central Committee) + ACTION_COMMENT notification type

CREATE TABLE IF NOT EXISTS `action_comments` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `action_point_id` INTEGER NOT NULL,
    `author_id` INTEGER NOT NULL,
    `body` TEXT NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (`id`),
    INDEX `ix_action_comments_action` (`action_point_id`, `created_at`),
    CONSTRAINT `action_comments_action_point_id_fkey`
      FOREIGN KEY (`action_point_id`) REFERENCES `action_points`(`id`)
      ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `action_comments_author_id_fkey`
      FOREIGN KEY (`author_id`) REFERENCES `users`(`id`)
      ON DELETE RESTRICT ON UPDATE CASCADE
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `notifications` MODIFY COLUMN `notification_type` ENUM(
  'CREATED',
  'DAILY_REMINDER',
  'OVERDUE_ESCALATION',
  'STATUS_CHANGE',
  'EVIDENCE_SUBMITTED',
  'EVIDENCE_VERIFIED',
  'MINUTES_ISSUED',
  'MEETING_ACTIONS_REMINDER',
  'MEETING_MINUTES_REMINDER',
  'ACTION_COMMENT'
) NOT NULL;
