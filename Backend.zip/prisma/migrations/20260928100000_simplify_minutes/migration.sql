-- Map legacy issued/approved rows to FINAL before narrowing the enum
UPDATE `meeting_minutes` SET `status` = 'FINAL' WHERE `status` IN ('ISSUED', 'APPROVED');

-- Drop old unique if needed and recreate after data fix is already done in prior migration

ALTER TABLE `meeting_minutes`
  DROP COLUMN `source_population`,
  DROP COLUMN `document_url`,
  DROP COLUMN `issued_at`,
  DROP COLUMN `approved_at`;

ALTER TABLE `meeting_minutes`
  MODIFY COLUMN `status` ENUM('DRAFT', 'FINAL') NOT NULL DEFAULT 'DRAFT';
