-- Central Committee sub-roles: MEMBER | ADMINISTRATOR
ALTER TABLE `users` ADD COLUMN `central_role` ENUM('MEMBER', 'ADMINISTRATOR') NULL;

-- Backfill from existing flags
UPDATE `users` SET `central_role` = 'ADMINISTRATOR' WHERE `is_admin` = true;
UPDATE `users` SET `central_role` = 'MEMBER' WHERE `is_central_committee` = true AND `is_admin` = false AND `central_role` IS NULL;

-- Admins are always Central members
UPDATE `users` SET `is_central_committee` = true WHERE `central_role` = 'ADMINISTRATOR';
