-- AlterTable
ALTER TABLE `meeting_minutes` ALTER COLUMN `updated_at` DROP DEFAULT;

-- RenameIndex
ALTER TABLE `meeting_minutes` RENAME INDEX `uq_meeting_minutes_status` TO `meeting_minutes_meeting_id_status_key`;
