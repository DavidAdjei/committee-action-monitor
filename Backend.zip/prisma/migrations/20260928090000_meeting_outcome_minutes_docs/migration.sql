-- Meeting outcome (did not hold / postponed)
ALTER TABLE `meetings`
  ADD COLUMN `outcome` ENUM('SCHEDULED', 'HELD', 'DID_NOT_HOLD', 'POSTPONED') NOT NULL DEFAULT 'SCHEDULED',
  ADD COLUMN `outcome_reason` TEXT NULL,
  ADD COLUMN `postponed_to` DATETIME(3) NULL,
  ADD COLUMN `outcome_recorded_at` DATETIME(3) NULL,
  ADD COLUMN `outcome_recorded_by_id` INTEGER NULL;

ALTER TABLE `meetings`
  ADD CONSTRAINT `meetings_outcome_recorded_by_id_fkey`
  FOREIGN KEY (`outcome_recorded_by_id`) REFERENCES `users`(`id`)
  ON DELETE SET NULL ON UPDATE CASCADE;

-- Minutes document metadata
ALTER TABLE `meeting_minutes`
  ADD COLUMN `storage_key` VARCHAR(500) NULL,
  ADD COLUMN `filename` VARCHAR(260) NULL,
  ADD COLUMN `media_type` VARCHAR(150) NULL,
  ADD COLUMN `size_bytes` INTEGER NULL,
  ADD COLUMN `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3);

-- Expand status enum for DRAFT + FINAL (keep ISSUED/APPROVED for existing rows)
ALTER TABLE `meeting_minutes`
  MODIFY COLUMN `status` ENUM('DRAFT', 'FINAL', 'ISSUED', 'APPROVED') NOT NULL DEFAULT 'DRAFT';

-- FK on meeting_id needs an index; unique(meeting_id) is currently that index.
-- Add a plain index first, then drop the unique so one draft + one final are allowed.
CREATE INDEX `meeting_minutes_meeting_id_idx` ON `meeting_minutes`(`meeting_id`);

ALTER TABLE `meeting_minutes` DROP INDEX `meeting_minutes_meeting_id_key`;

-- One row per (meeting, status) — allows one DRAFT and one FINAL per meeting
CREATE UNIQUE INDEX `uq_meeting_minutes_status` ON `meeting_minutes`(`meeting_id`, `status`);
