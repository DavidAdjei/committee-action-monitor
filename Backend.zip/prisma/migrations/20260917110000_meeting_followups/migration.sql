-- New notification types for post-meeting secretary follow-ups
ALTER TABLE `notifications` MODIFY COLUMN `notification_type` ENUM(
  'CREATED',
  'DAILY_REMINDER',
  'OVERDUE_ESCALATION',
  'STATUS_CHANGE',
  'EVIDENCE_SUBMITTED',
  'EVIDENCE_VERIFIED',
  'MINUTES_ISSUED',
  'MEETING_ACTIONS_REMINDER',
  'MEETING_MINUTES_REMINDER'
) NOT NULL;

-- At most one minutes record per meeting
-- Drop duplicates keeping the lowest id first (safe no-op if already unique)
DELETE m1 FROM `meeting_minutes` m1
INNER JOIN `meeting_minutes` m2
  ON m1.meeting_id = m2.meeting_id AND m1.id > m2.id;

CREATE UNIQUE INDEX `meeting_minutes_meeting_id_key` ON `meeting_minutes`(`meeting_id`);
