-- Allow committees without a Central Committee representative (seed / legacy)
ALTER TABLE `committees` MODIFY COLUMN `central_rep_id` INTEGER NULL;
