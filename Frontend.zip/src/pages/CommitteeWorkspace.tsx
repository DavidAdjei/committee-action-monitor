import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { CalendarPlus, Crown, Eye, FileText, ListPlus, MessageSquare, QrCode, ShieldCheck, Trash2, Upload, UserPlus, Video } from "lucide-react";
import { endpoints } from "@/api/endpoints";
import { StatusPill, DueBadge, ProgressBar, formatDate } from "@/components/StatusBits";
import { NewActionModal } from "@/components/modals/NewActionModal";
import { CreateMeetingModal } from "@/components/modals/CreateMeetingModal";
import { ImportDocumentModal } from "@/components/modals/ImportDocumentModal";
import { AddMemberModal } from "@/components/modals/AddMemberModal";
import { SetChairModal } from "@/components/modals/SetChairModal";
import { SetCentralRepModal } from "@/components/modals/SetCentralRepModal";
import { ActionCommentsModal } from "@/components/modals/ActionCommentsModal";
import { MinutesDetailPanel } from "@/components/MinutesDetailPanel";
import { LoadingLogo } from "@/components/LoadingLogo";
import { useAuth } from "@/state/authContext";
import { useFlash } from "@/state/toastContext";
import { ApiClientError } from "@/api/client";
import {
  canCreateAction,
  canCreateMeeting,
  canCreateMinutes,
  canManageCommittee,
  canManageMembers,
} from "@/lib/permissions";
// canCreateMinutes still used for canEdit officer gate
import { AttendanceQrProjector } from "@/components/AttendanceQrProjector";
import type { ActionListItem, CommitteeDetail, Meeting, MeetingMinutes } from "@/types";

const TABS = ["Overview", "Action Points", "Meetings", "Minutes"] as const;
type Tab = (typeof TABS)[number];

function isMeetingLive(startsAt: string, endsAt?: string | null): boolean {
  const now = Date.now();
  const start = new Date(startsAt).getTime();
  const end = endsAt ? new Date(endsAt).getTime() : start + 3 * 60 * 60 * 1000;
  return now >= start && now <= end;
}

export default function CommitteeWorkspace() {
  const { me } = useAuth();
  const flash = useFlash();
  const navigate = useNavigate();
  const { id } = useParams();
  const committeeId = Number(id);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [detail, setDetail] = useState<CommitteeDetail | null>(null);
  const [actions, setActions] = useState<ActionListItem[]>([]);
  const [tab, setTab] = useState<Tab>("Overview");
  const [statusFilter, setStatusFilter] = useState("All");
  const [showNewAction, setShowNewAction] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [commentsFor, setCommentsFor] = useState<{
    id: number;
    referenceNo: string;
    title: string;
    mode: "view" | "add";
  } | null>(null);
  const [showNewMeeting, setShowNewMeeting] = useState(false);
  const [showAddMember, setShowAddMember] = useState(false);
  const [showSetChair, setShowSetChair] = useState(false);
  const [showSetCentralRep, setShowSetCentralRep] = useState(false);
  const [minutesList, setMinutesList] = useState<MeetingMinutes[]>([]);
  const [minutesLoading, setMinutesLoading] = useState(false);
  const [openMinutesId, setOpenMinutesId] = useState<number | null>(null);
  const [projectMeeting, setProjectMeeting] = useState<{
    title: string;
    reference: string;
    checkInUrl: string;
  } | null>(null);
  const [projectLoadingId, setProjectLoadingId] = useState<number | null>(null);
  const [distroDraft, setDistroDraft] = useState("");
  const [distroBusy, setDistroBusy] = useState(false);
  const [showSecTip, setShowSecTip] = useState(() => {
    try {
      return localStorage.getItem("cam.secretaryTip.dismissed") !== "1";
    } catch {
      return true;
    }
  });

  const handleAccessDenied = (err: unknown) => {
    const message =
      err instanceof ApiClientError
        ? err.message
        : (err as Error)?.message ?? "You do not have access to this committee.";
    setLoadError(message);
    flash(message, "error");
    navigate("/committees", { replace: true });
  };

  const loadDetail = () =>
    endpoints
      .committee(committeeId)
      .then((d) => {
        setDetail(d);
        setLoadError(null);
      })
      .catch(handleAccessDenied);

  const loadActions = () =>
    endpoints
      .actionsForCommittee(committeeId, statusFilter !== "All" ? { status: statusFilter } : undefined)
      .then(setActions)
      .catch((err) => {
        // Don't loop loaders on secondary failures if detail already failed
        if (!detail) handleAccessDenied(err);
      });

  const loadMinutes = async () => {
    setMinutesLoading(true);
    try {
      const meetings = detail?.meetings ?? (await endpoints.committee(committeeId)).meetings;
      const lists = await Promise.all(
        (meetings ?? []).map((m) => endpoints.listMeetingMinutes(m.id).catch(() => [] as MeetingMinutes[])),
      );
      const flat = lists.flat().sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
      setMinutesList(flat);
    } finally {
      setMinutesLoading(false);
    }
  };

  useEffect(() => {
    loadDetail();
  }, [committeeId]);

  useEffect(() => {
    loadActions();
  }, [committeeId, statusFilter]);

  useEffect(() => {
    if (tab === "Minutes") void loadMinutes();
  }, [tab, committeeId, detail?.meetings?.length]);

  const refreshAll = () => {
    loadDetail();
    loadActions();
    if (tab === "Minutes") void loadMinutes();
  };


  const openAttendanceProjector = async (meeting: Meeting) => {
    setProjectLoadingId(meeting.id);
    try {
      const d: any = await endpoints.meetingDetail(meeting.id);
      const token = d.attendanceToken as string | undefined;
      if (!token) {
        flash("Attendance QR is only available to the Chairperson or Secretary.", "error");
        return;
      }
      const origin = window.location.origin;
      const checkInUrl = `${origin}/meetings/${meeting.id}/check-in?token=${token}`;
      setProjectMeeting({
        title: d.title ?? meeting.title,
        reference: d.reference ?? meeting.reference,
        checkInUrl,
      });
    } catch (err: unknown) {
      flash(err instanceof ApiClientError ? err.message : "Could not load attendance QR.", "error");
    } finally {
      setProjectLoadingId(null);
    }
  };

  useEffect(() => {
    if (detail?.distributionEmail != null) setDistroDraft(detail.distributionEmail);
    else if (detail) setDistroDraft("");
  }, [detail?.id, detail?.distributionEmail]);

  if (loadError) {
    return (
      <div className="card border-red-200 bg-red-50 p-6 text-center dark:border-red-900 dark:bg-red-950">
        <p className="text-sm text-red-700 dark:text-red-300">{loadError}</p>
        <p className="mt-1 text-xs text-red-500">Redirecting to committees…</p>
      </div>
    );
  }

  if (!detail) return <LoadingLogo scope="page" message="Loading committee workspace..." />;

  // Server flags are authoritative when present. Client matrix is a fail-closed fallback
  // and a second gate on write forms (docs §2 / §9 — UI is not the security control).
  const canEdit =
    detail.canEdit !== undefined && detail.canEdit !== null
      ? Boolean(detail.canEdit)
      : canCreateAction(me, committeeId) || canCreateMeeting(me, committeeId) || canCreateMinutes(me, committeeId);
  const canManage =
    detail.canManageCommittee !== undefined && detail.canManageCommittee !== null
      ? Boolean(detail.canManageCommittee)
      : canManageCommittee(me, committeeId);
  const canMembers =
    detail.canManageMembers !== undefined && detail.canManageMembers !== null
      ? Boolean(detail.canManageMembers)
      : canManageMembers(me, committeeId);

  return (
    <div className="space-y-5">
      {canEdit && showSecTip && (
        <div className="rounded-xl border border-brand-200 bg-brand-50/80 px-4 py-3 text-sm dark:border-brand-800 dark:bg-brand-950/30">
          <div className="flex flex-wrap items-start justify-between gap-2">
            <div>
              <p className="font-semibold text-brand-900 dark:text-brand-100">Secretary quick start</p>
              <ol className="mt-1 list-decimal space-y-0.5 pl-4 text-xs text-brand-800 dark:text-brand-200">
                <li>Schedule a meeting (optional Teams + papers).</li>
                <li>After it runs: record outcome → upload minutes → raise actions.</li>
                <li>Owners get email; you verify completion when they submit.</li>
              </ol>
            </div>
            <button
              type="button"
              className="text-xs font-semibold text-brand-700 hover:underline dark:text-brand-300"
              onClick={() => {
                try {
                  localStorage.setItem("cam.secretaryTip.dismissed", "1");
                } catch {
                  /* ignore */
                }
                setShowSecTip(false);
              }}
            >
              Dismiss
            </button>
          </div>
        </div>
      )}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl font-bold text-ink dark:text-white">{detail.name}</h1>
            {detail.code && (
              <span className="rounded bg-slate-100 dark:bg-slate-800 px-2 py-0.5 font-mono text-xs font-semibold text-slate-600 dark:text-slate-300">
                {detail.code}
              </span>
            )}
            {!canEdit && (
              <span className="inline-flex items-center gap-1 rounded-md border border-amber-200 bg-amber-50 px-2 py-0.5 text-xs font-semibold text-amber-800 dark:border-amber-900 dark:bg-amber-950/70 dark:text-amber-300">
                <Eye className="h-3.5 w-3.5 text-amber-600" /> View Only
              </span>
            )}
          </div>
          <p className="mt-1 max-w-2xl text-sm text-slate-500 dark:text-slate-400">{detail.mandate}</p>
          <p className="mt-1.5 text-xs text-slate-400 dark:text-slate-500">
            Chairperson:{" "}
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              {detail.chairperson?.fullName ?? "None"}
            </span>{" "}
            · Secretary:{" "}
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              {detail.secretary?.fullName ?? "None"}
            </span>{" "}
            · Central rep:{" "}
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              {detail.centralRep?.fullName ?? "None"}
            </span>
            {canManage && (
              <>
                {" "}
                <button
                  type="button"
                  className="text-xs font-semibold text-brand-600 dark:text-brand-400 hover:underline"
                  onClick={() => setShowSetCentralRep(true)}
                >
                  Change
                </button>
              </>
            )}
          </p>
          {(canEdit || me?.isAdmin) && (
            <div className="mt-2 flex flex-wrap items-end gap-2 text-sm">
              <label className="field-label min-w-[220px] flex-1">
                Distribution email
                <input
                  className="field-input"
                  type="email"
                  placeholder="e.g. ALCO@myumbbank.com"
                  value={distroDraft}
                  onChange={(e) => setDistroDraft(e.target.value)}
                />
              </label>
              <button
                type="button"
                className="btn text-xs"
                disabled={distroBusy}
                onClick={() => {
                  void (async () => {
                    setDistroBusy(true);
                    try {
                      await endpoints.setCommitteeDistributionEmail(
                        committeeId,
                        distroDraft.trim() || null,
                      );
                      flash("Distribution email saved");
                      await refreshAll();
                    } catch (err: unknown) {
                      flash(
                        err instanceof ApiClientError ? err.message : "Could not save distribution email.",
                        "error",
                      );
                    } finally {
                      setDistroBusy(false);
                    }
                  })();
                }}
              >
                {distroBusy ? "Saving…" : "Save"}
              </button>
            </div>
          )}
          {!canEdit && !me?.isAdmin && detail.distributionEmail && (
            <p className="mt-1 text-xs text-slate-500">
              Distribution list: {detail.distributionEmail}
            </p>
          )}

        </div>

        {/* Action / Governance Buttons */}
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {/* Central Committee / Admin: reassign chair */}
          {canManage && (
            <button
              className="btn gap-1.5 text-xs"
              onClick={() => setShowSetChair(true)}
              title="Assign or reassign the committee chairperson"
            >
              <Crown className="h-4 w-4 text-brand-500" /> Set Chair
            </button>
          )}
          {/* Chair / Secretary (or admin): add members and roles */}
          {canMembers && (
            <button
              className="btn gap-1.5 text-xs"
              onClick={() => setShowAddMember(true)}
              title="Add a new member to this committee"
            >
              <UserPlus className="h-4 w-4 text-slate-600 dark:text-slate-300" /> Add member
            </button>
          )}

          {/* Committee Officer Controls: Only visible to Chairperson & Secretary */}
          {canEdit ? (
            <>
              <button className="btn gap-1.5 text-xs" onClick={() => setShowNewMeeting(true)}>
                <CalendarPlus className="h-4 w-4 text-slate-600 dark:text-slate-300" /> New meeting
              </button>
              <button className="btn gap-1.5 text-xs" onClick={() => setShowImport(true)}>
                <Upload className="h-4 w-4 text-slate-600 dark:text-slate-300" /> Import
              </button>
              <button className="btn-primary gap-1.5 text-xs" onClick={() => setShowNewAction(true)}>
                <ListPlus className="h-4 w-4" /> New action point
              </button>
            </>
          ) : (
            <span
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-500 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400"
              title="Only the committee's active Chairperson or Secretary may create meetings and action points."
            >
              <ShieldCheck className="h-4 w-4 text-brand-500" /> View-only access
            </span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4">
        <SummaryTile label="Action points" value={detail.summary.totalActions} />
        <SummaryTile label="Still open" value={detail.summary.activeActions} tone="text-blue-600" />
        <SummaryTile label="Overdue" value={detail.summary.overdueActions} tone="text-red-600" />
        <SummaryTile label="On-time rate" value={`${detail.summary.onTimeRate ?? "—"}%`} tone="text-emerald-600" />
      </div>

      <div className="flex gap-1 border-b border-slate-200">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2.5 text-sm font-medium ${
              tab === t ? "border-b-2 border-brand-600 text-brand-700 dark:text-brand-300" : "text-slate-500 hover:text-slate-700 dark:text-slate-200"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === "Overview" && (
        <div className="space-y-4">
          {(() => {
            const nowMs = Date.now();
            const withWindow = detail.meetings.map((m) => {
              const start = new Date(m.startsAt).getTime();
              const end = m.endsAt
                ? new Date(m.endsAt).getTime()
                : start + 3 * 60 * 60 * 1000;
              return { m, start, end };
            });
            const ongoing = withWindow.filter(({ start, end }) => start <= nowMs && nowMs <= end);
            const upcoming = withWindow
              .filter(({ start }) => start > nowMs && start - nowMs < 24 * 60 * 60 * 1000)
              .sort((a, b) => a.start - b.start);

            if (ongoing.length === 0 && upcoming.length === 0) {
              return (
                <div className="card border-dashed border-slate-200 bg-slate-50/50 dark:border-slate-700 dark:bg-slate-900/40">
                  <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">No meeting in session</p>
                  <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                    When a meeting is underway (between start and end time), it appears here with a live badge and attendance QR for the Chairperson or Secretary.
                  </p>
                </div>
              );
            }

            const renderCard = (
              m: (typeof detail.meetings)[number],
              mode: "live" | "upcoming",
            ) => (
                  <div
                    key={`${mode}-${m.id}`}
                    className={
                      mode === "live"
                        ? "card border-brand-300 bg-gradient-to-r from-brand-50 to-white dark:border-brand-800 dark:from-brand-950/40 dark:to-slate-800"
                        : "card border-slate-200 dark:border-slate-700"
                    }
                  >
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <div className="mb-1 flex flex-wrap items-center gap-2">
                          <span
                            className={
                              mode === "live"
                                ? "inline-flex items-center rounded-full bg-emerald-100 px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wide text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300"
                                : "inline-flex items-center rounded-full bg-amber-100 px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wide text-amber-800 dark:bg-amber-950 dark:text-amber-300"
                            }
                          >
                            {mode === "live" ? "Live now" : "Starting soon"}
                          </span>
                          <span className="text-xs text-slate-500 dark:text-slate-400">{m.reference}</span>
                        </div>
                        <b className="text-base text-slate-900 dark:text-white">{m.title}</b>
                        <p className="mt-0.5 text-sm text-slate-600 dark:text-slate-300">
                          {new Date(m.startsAt).toLocaleString(undefined, {
                            weekday: "short",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                          {m.endsAt
                            ? ` – ${new Date(m.endsAt).toLocaleTimeString(undefined, {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}`
                            : ""}
                          {m.venue ? ` · ${m.venue}` : ""}
                        </p>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {mode === "live" && canMembers && isMeetingLive(m.startsAt, m.endsAt) && (
                          <button
                            type="button"
                            className="btn text-xs"
                            disabled={projectLoadingId === m.id}
                            onClick={() => void openAttendanceProjector(m)}
                          >
                            <QrCode className="h-3.5 w-3.5" />
                            {projectLoadingId === m.id ? "Loading QR…" : "Project attendance QR"}
                          </button>
                        )}
                        <button type="button" className="btn text-xs" onClick={() => navigate(`/meetings/${m.id}`)}>
                          View meeting
                        </button>
                      </div>
                    </div>
                  </div>
            );

            return (
              <div className="space-y-3">
                {ongoing.map(({ m }) => renderCard(m, "live"))}
                {upcoming.map(({ m }) => renderCard(m, "upcoming"))}
              </div>
            );
          })()}

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div className="card">
            <b className="mb-3 block text-sm text-slate-800 dark:text-slate-100">Pending verification</b>
            {detail.pendingVerification.length === 0 && (
              <p className="text-sm text-slate-400">Nothing awaiting verification.</p>
            )}
            <div className="space-y-2">
              {detail.pendingVerification.map((p) => (
                <button
                  key={p.id}
                  onClick={() => navigate(`/actions/${p.id}`)}
                  className="flex w-full items-center justify-between rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-left text-sm hover:bg-amber-100 dark:hover:bg-amber-900/40"
                >
                  <span>
                    <b>{p.referenceNo}</b> · {p.title}
                    <br />
                    <small className="text-slate-500">Owner: {p.owner.fullName}</small>
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="card">
            <div className="mb-3 flex items-center justify-between">
              <b className="text-sm font-bold text-slate-800 dark:text-slate-100">Committee Members</b>
              <div className="flex items-center gap-2">
                {canManage && (
                  <button
                    onClick={() => setShowSetChair(true)}
                    className="flex items-center gap-1 text-xs font-semibold text-brand-600 dark:text-brand-400 hover:underline"
                  >
                    <Crown className="h-3 w-3" /> Set Chair
                  </button>
                )}
                {canManage && canMembers && (
                  <span className="text-slate-300 dark:text-slate-600">·</span>
                )}
                {canMembers && (
                  <button
                    onClick={() => setShowAddMember(true)}
                    className="flex items-center gap-1 text-xs font-semibold text-brand-600 dark:text-brand-400 hover:underline"
                  >
                    <UserPlus className="h-3 w-3" /> Add Member
                  </button>
                )}
              </div>
            </div>
            <p className="mb-2 text-xs text-slate-500">
              {detail.members.length} active member{detail.members.length === 1 ? "" : "s"}
              {canMembers ? " · Chairperson and Secretary can add or remove members" : ""}
            </p>
            <div className="max-h-72 space-y-1.5 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-700 dark:divide-slate-800">
              {detail.members.length === 0 && (
                <p className="py-2 text-sm text-slate-400">No members listed yet.</p>
              )}
              {detail.members.map((m) => {
                const isProtectedSeat =
                  m.userId === detail.chairperson?.id || m.userId === detail.secretary?.id;
                return (
                  <div key={m.userId} className="flex items-center justify-between gap-2 py-1.5 text-sm">
                    <div className="min-w-0">
                      <span className="font-medium text-slate-800 dark:text-slate-200">{m.fullName}</span>
                      {m.email && (
                        <span className="mt-0.5 block truncate text-xs text-slate-400">{m.email}</span>
                      )}
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      <span
                        className={`rounded-full px-2 py-0.5 text-xs font-semibold ${
                          m.role === "CHAIRPERSON"
                            ? "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300"
                            : m.role === "SECRETARY"
                              ? "bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300"
                              : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300"
                        }`}
                      >
                        {m.role === "CHAIRPERSON"
                          ? "Chairperson"
                          : m.role === "SECRETARY"
                            ? "Secretary"
                            : "Member"}
                      </span>
                      {canMembers && !isProtectedSeat && (
                        <button
                          type="button"
                          className="rounded-md p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/40 dark:hover:text-red-400"
                          title="Remove from committee"
                          onClick={async (e) => {
                            e.stopPropagation();
                            if (
                              !window.confirm(
                                `Remove ${m.fullName} from this committee?`,
                              )
                            ) {
                              return;
                            }
                            try {
                              await endpoints.removeCommitteeMember(committeeId, m.userId);
                              flash(`${m.fullName} removed from the committee`);
                              const d = await endpoints.committee(committeeId);
                              setDetail(d);
                            } catch (err: unknown) {
                              flash(
                                err instanceof ApiClientError
                                  ? err.message
                                  : "Could not remove member.",
                                "error",
                              );
                            }
                          }}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        </div>
      )}

      {tab === "Action Points" && (
        <div className="card">
          <div className="mb-4 flex items-center gap-2">
            {["All", "Open", "In Progress", "Pending Verification", "Overdue", "Completed"].map((s) => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={`rounded-full px-3 py-1.5 text-xs font-medium ${
                  statusFilter === s ? "bg-brand-600 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200 dark:hover:bg-slate-800/50"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-xs uppercase tracking-wide text-slate-400">
                <th className="pb-2">Action</th>
                <th className="pb-2">Owner</th>
                <th className="pb-2">Deadline</th>
                <th className="pb-2">Progress</th>
                <th className="pb-2">Status</th>
                <th className="pb-2">Comments</th>
              </tr>
            </thead>
            <tbody>
              {actions.map((a) => (
                <tr
                  key={a.id}
                  onClick={() => navigate(`/actions/${a.id}`)}
                  className="cursor-pointer border-b border-slate-100 dark:border-slate-700 last:border-0 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                >
                  <td className="py-2.5">{a.title}</td>
                  <td className="py-2.5">{a.owner.fullName}</td>
                  <td className="py-2.5">
                    {formatDate(a.deadline)}
                    <br />
                    <DueBadge deadline={a.deadline} status={a.status} />
                  </td>
                  <td className="py-2.5">
                    <ProgressBar value={a.progress} />
                  </td>
                  <td className="py-2.5">
                    <StatusPill status={a.status} />
                  </td>
                  <td className="py-2.5" onClick={(e) => e.stopPropagation()}>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <button
                        type="button"
                        className="btn px-2 py-1 text-[11px]"
                        title="View comments"
                        onClick={() =>
                          setCommentsFor({
                            id: a.id,
                            referenceNo: a.referenceNo,
                            title: a.title,
                            mode: "view",
                          })
                        }
                      >
                        <MessageSquare className="h-3.5 w-3.5" />
                        {(a.commentCount ?? 0) > 0 ? a.commentCount : "View"}
                      </button>
                      {(me?.isCentralCommittee || me?.isAdmin) && (
                        <button
                          type="button"
                          className="btn-primary px-2 py-1 text-[11px]"
                          title="Add comment"
                          onClick={() =>
                            setCommentsFor({
                              id: a.id,
                              referenceNo: a.referenceNo,
                              title: a.title,
                              mode: "add",
                            })
                          }
                        >
                          Add
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {actions.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-6 text-center text-slate-400">
                    No action points for this filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {tab === "Meetings" && (
        <div className="space-y-3">
          {detail.meetings.map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => navigate(`/meetings/${m.id}`)}
              className="card flex w-full flex-col gap-2 text-left transition hover:border-brand-300 hover:shadow-md sm:flex-row sm:items-center sm:justify-between"
            >
              <div>
                <b className="text-sm text-slate-800 dark:text-slate-100">{m.title}</b>
                <p className="text-xs text-slate-500">
                  {m.reference} · {formatDate(m.startsAt)} · {m.venue || "No venue"}
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {m.teamsJoinUrl && (
                  <span
                    role="link"
                    onClick={(e) => {
                      e.stopPropagation();
                      window.open(m.teamsJoinUrl!, "_blank", "noopener,noreferrer");
                    }}
                    className="btn text-xs"
                  >
                    <Video className="h-4 w-4" /> Join Teams
                  </span>
                )}
                <span className="text-xs font-medium text-brand-600">View details →</span>
              </div>
            </button>
          ))}
          {detail.meetings.length === 0 && <p className="card text-sm text-slate-400">No meetings recorded yet.</p>}
        </div>
      )}

      {tab === "Minutes" && (
        <div className="space-y-3">
          {minutesLoading && <p className="text-sm text-slate-400">Loading minutes…</p>}
          {!minutesLoading &&
            minutesList.map((min) => (
              <button
                key={min.id}
                type="button"
                onClick={() => setOpenMinutesId(min.id)}
                className="card flex w-full flex-col gap-2 text-left transition hover:border-brand-300 hover:shadow-md sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <b className="text-sm text-slate-800 dark:text-slate-100">
                      {min.meeting.reference} · {min.meeting.title}
                    </b>
                    <span
                      className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${
                        min.status === "FINAL"
                          ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300"
                          : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300"
                      }`}
                    >
                      {min.status}
                    </span>
                  </div>
                  <p className="mt-0.5 text-xs text-slate-500">
                    {min.snapshots?.length ?? 0} action snapshot
                    {(min.snapshots?.length ?? 0) === 1 ? "" : "s"} · Created {formatDate(min.createdAt)} by{" "}
                    {min.createdBy.fullName}
                    {min.filename ? ` · ${min.filename}` : ""}
                  </p>
                </div>
                <span className="shrink-0 text-xs font-medium text-brand-600">View details →</span>
              </button>
            ))}
          {!minutesLoading && minutesList.length === 0 && (
            <p className="card text-sm text-slate-400">
              No minutes yet. Use <b>Import</b> to upload a draft or final minutes document for a meeting.
            </p>
          )}
        </div>
      )}

      {showImport && (
        <ImportDocumentModal
          committeeId={committeeId}
          committeeName={detail.name}
          onClose={() => setShowImport(false)}
          onImported={async () => {
            setShowImport(false);
            flash("Import completed successfully");
            const d = await endpoints.committee(committeeId);
            setDetail(d);
            setTab("Action Points");
          }}
        />
      )}

      {showNewAction && (
        <NewActionModal
          committeeId={committeeId}
          committeeName={detail.name}
          onClose={() => setShowNewAction(false)}
          onCreated={refreshAll}
        />
      )}
      {showNewMeeting && (
        <CreateMeetingModal
          committeeId={committeeId}
          committeeName={detail.name}
          onClose={() => setShowNewMeeting(false)}
          onCreated={refreshAll}
        />
      )}
      {commentsFor && (
        <ActionCommentsModal
          actionId={commentsFor.id}
          referenceNo={commentsFor.referenceNo}
          title={commentsFor.title}
          mode={commentsFor.mode}
          onClose={() => setCommentsFor(null)}
          onChanged={refreshAll}
        />
      )}
      {openMinutesId && (
        <MinutesDetailPanel
          minutesId={openMinutesId}
          onClose={() => setOpenMinutesId(null)}
          onChanged={() => {
            void loadMinutes();
            refreshAll();
          }}
        />
      )}
      {projectMeeting && (
        <AttendanceQrProjector
          meetingTitle={projectMeeting.title}
          meetingReference={projectMeeting.reference}
          checkInUrl={projectMeeting.checkInUrl}
          onClose={() => setProjectMeeting(null)}
        />
      )}


      {showSetChair && (
        <SetChairModal
          committeeId={committeeId}
          committeeName={detail.name}
          currentChairperson={detail.chairperson}
          onClose={() => setShowSetChair(false)}
          onChanged={refreshAll}
        />
      )}
      {showAddMember && (
        <AddMemberModal
          committeeId={committeeId}
          committeeName={detail.name}
          existingMemberIds={detail.members.map((m) => m.userId)}
          onClose={() => setShowAddMember(false)}
          onAdded={refreshAll}
        />
      )}
      {showSetCentralRep && (
        <SetCentralRepModal
          committeeId={committeeId}
          committeeName={detail.name}
          currentRepId={detail.centralRep?.id ?? null}
          onClose={() => setShowSetCentralRep(false)}
          onSaved={refreshAll}
        />
      )}
    </div>
  );
}

function SummaryTile({ label, value, tone = "text-ink dark:text-white" }: { label: string; value: string | number; tone?: string }) {
  return (
    <div className="card">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-400">{label}</p>
      <p className={`text-2xl font-bold ${tone}`}>{value}</p>
    </div>
  );
}
